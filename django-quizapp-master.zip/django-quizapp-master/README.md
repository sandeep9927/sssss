# Quiz App
This is a simple quiz application created using the django framework.


Visit:
http://djangoquizsam.azurewebsites.net
