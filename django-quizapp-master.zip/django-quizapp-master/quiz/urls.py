from . import views
from django.urls import path

urlpatterns = [
    path('',views.firsthome,name='firsthome'),
    path('Quiz-Home-Dashboard', views.homeViews,name="home-page"),
    path('Word-Matching-Quiz-System',views.WordquestionQuiz,name='WordquestionQuiz'),
    path('result', views.result,name="result"),
    path('contact', views.contact,name="contact"),
    path('<choice>', views.questions, name = 'questions'),
]
