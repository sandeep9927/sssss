from django.shortcuts import render,redirect
from .models import *


# Create your views here.
def firsthome(request):
        return render(request,'quiz/firsthome.htm')


def homeViews(request):
    choices = TotalQuestions.CAT_CHOICES
    print(choices)
    return render(request,
        'quiz/home.html',
        {'choices':choices})

def questions(request , choice):
    print(choice)
    getquestionsdata = TotalQuestions.objects.filter(catagory__exact = choice)
    return render(request,
        'quiz/questions.html',
        {'getquestionsdata':getquestionsdata})


def result(request):
        Allquestions = TotalQuestions.objects.all()
        score=0

        for question in Allquestions:
                Rigth_ans=question.answer
                Num_Quse=request.POST.get(str(question.id))
                
                if (Num_Quse== Rigth_ans):

                        score +=1
        total=len(Allquestions)
        Efficiency = (score/total)*100

        

                
        return render(request,
                'quiz/result.html',
                {'score':score,
                'Efficiency':Efficiency,
                'total':total})

def contact(request):
    return render(request,
        'quiz/contact.html')

             
                
def WordquestionQuiz(request):
        wordquestiondata=Wordmatching.objects.all()
        return render(request,'quiz/wordmatching.htm',{'wordquestiondata':wordquestiondata})


# def wordmatchingresult(request):
#         Allwordcheck=Wordmatching.objects.all()
     







