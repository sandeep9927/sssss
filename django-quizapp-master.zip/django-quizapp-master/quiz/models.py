from django.db import models

# Create your models here.

class TotalQuestions(models.Model):
    CAT_CHOICES = (
    ('sports','Sports'),
    ('movies','Movies'),
    ('maths','Maths'),
    
    )
    catagory = models.CharField(max_length=20, choices = CAT_CHOICES)
    question = models.CharField(max_length = 250)
    optiona = models.CharField(max_length = 100)
    optionb = models.CharField(max_length = 100)
    optionc = models.CharField(max_length = 100)
    optiond = models.CharField(max_length = 100)
    answer = models.CharField(max_length = 100)
  
    

    class Meta:
        ordering = ('-catagory',)

    def __str__(self):
        return self.question


class Wordmatching(models.Model):
    wordquestion=models.CharField( max_length=300)
    awordoption=models.CharField(max_length=50)
    bwordoption=models.CharField(max_length=50)
    cwordoption=models.CharField(max_length=50)
    dwordoption=models.CharField(max_length=50)
    ewordoption=models.CharField(max_length=50)
    fwordoption=models.CharField(max_length=50)
    gwordoption=models.CharField(max_length=50)
    hwordoption=models.CharField(max_length=50)
    iwordoption=models.CharField(max_length=50)
    jwordoption=models.CharField(max_length=50)
    kwordoption=models.CharField(max_length=50,null=True)
    lwordoption=models.CharField(max_length=50,null=True)
    answer1=models.CharField( max_length=300,null=True)


    def __str__(self):
        return self.wordquestion
    





