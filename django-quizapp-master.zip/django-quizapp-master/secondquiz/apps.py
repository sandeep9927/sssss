from django.apps import AppConfig


class SecondquizConfig(AppConfig):
    name = 'secondquiz'
