from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path,include
from users import views as user_view

urlpatterns = [
    path('admin', admin.site.urls),
    path('', include('quiz.urls')),
    path('register/',user_view.register,name='register'),
    path('login/',auth_views.LoginView.as_view(template_name='users/login.htm'),name='login'),
    path('logout/',auth_views.LogoutView.as_view(template_name='users/logout.htm'),name='logout'),
    path('password-reset/',auth_views.PasswordResetView.as_view
    (template_name='users/password_reset.htm'),
    name='password_reset'),
    path('password-reset/done',auth_views.PasswordResetDoneView.as_view
    (template_name='users/password_reset_done.htm'),
    name='password_reset_done'),

    path('password-reset-confirm/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view
    (template_name='users/password_reset_confirm.htm'),
    name='password_reset_confirm'),
    path('quiz/', include('quiz.urls')),
    
    
    

]



