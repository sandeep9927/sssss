# ecommerce-with-django2-tutorial

code lectuer

[01 create an online shope project](https://github.com/mhadiahmed/ecommerce-with-django2-tutorial/tree/c61e50b82b369832dbecfb7157ea084e85ea78e4)

[02 Building a shopping cart](https://github.com/mhadiahmed/ecommerce-with-django2-tutorial/tree/4cb7c38bddb018f94be99468546a52e5659e7cd3)

[03 Creating shopping cart views](https://github.com/mhadiahmed/ecommerce-with-django2-tutorial/tree/ea9cfa7b5badf43b5cea86145c0c6fe9b41a5d38)


[04 Creating a context processor for the current cart](https://github.com/mhadiahmed/ecommerce-with-django2-tutorial/tree/449703f2317e2421855335a8bc95a25c68241990)



[05 Registering customer orders](https://github.com/mhadiahmed/ecommerce-with-django2-tutorial/tree/e7dd6b3a065bbfb403eda274a1f6d4cf0b12304b)


[06 Integrating a payment gateway](https://github.com/mhadiahmed/ecommerce-with-django2-tutorial/tree/bdfa19d48eb53d3487cb06f57e8eb3a35d4a6e1d)



