from django.apps import AppConfig


class NewsearchConfig(AppConfig):
    name = 'newsearch'
