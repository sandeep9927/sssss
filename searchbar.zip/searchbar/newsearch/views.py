from django.shortcuts import render
from .models import *

# Create your views here.
def searchbar(request):
    allcountry=search.objects.all()

    return render(request,'search.html',{'allcountry':allcountry})