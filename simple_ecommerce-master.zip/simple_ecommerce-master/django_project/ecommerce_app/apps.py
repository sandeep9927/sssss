from django.apps import AppConfig


class EcommerceAppConfig(AppConfig):
    name = 'ecommerce_app'
